CREATE DATABASE  IF NOT EXISTS `u895244394_bams` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `u895244394_bams`;
-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: u895244394_bams
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `id_type`
--

DROP TABLE IF EXISTS `id_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `id_type` (
  `id_type_id` int NOT NULL AUTO_INCREMENT,
  `id_type_desc` varchar(50) NOT NULL,
  `id_type_created_by` varchar(50) NOT NULL,
  `id_type_deleted_by` varchar(50) NOT NULL,
  `id_type_updated_by` varchar(50) NOT NULL,
  `id_type_created_at` datetime NOT NULL,
  `id_type_updated_at` datetime NOT NULL,
  `id_type_deleted_at` datetime NOT NULL,
  PRIMARY KEY (`id_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `id_type`
--

LOCK TABLES `id_type` WRITE;
/*!40000 ALTER TABLE `id_type` DISABLE KEYS */;
INSERT INTO `id_type` VALUES (1,'e-Card / UMID','','','','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),(2,'Employee’s ID','','','','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),(3,'Driver’s Licens','','','','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),(4,'Professional Regulation Commission (PRC) ID','','','','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),(5,'Passport','','','','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),(6,'Senior Citizen ID','','','','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),(7,'SSS ID','','','','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),(8,'COMELEC / Voter’s ID / COMELEC Registration Form','','','','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),(9,'Philippine Identification (PhilID / ePhilID)','','','','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),(10,'NBI Clearance','','','','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),(11,'Integrated Bar of the Philippines (IBP) ID','','','','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),(12,'Firearms License','','','','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),(13,'AFPSLAI ID','','','','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),(14,'PVAO ID','','','','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),(15,'AFP Beneficiary ID','','','','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),(16,'BIR (TIN)','','','','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),(17,'Pag-ibig ID','','','','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),(18,'Person’s With Disability (PWD) ID','','','','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),(19,'Solo Parent ID','','','','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),(20,'Pantawid Pamilya Pilipino Program (4Ps) ID','','','','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),(21,'Barangay ID','','','','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),(22,'Philippine Postal ID','','','','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),(23,'Phil-health ID','','','','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00'),(24,'School ID','','','','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `id_type` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-31 18:06:23
