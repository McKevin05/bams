CREATE DATABASE  IF NOT EXISTS `u895244394_bams` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `u895244394_bams`;
-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: u895244394_bams
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `resident_info`
--

DROP TABLE IF EXISTS `resident_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `resident_info` (
  `resident_info_id` int NOT NULL AUTO_INCREMENT,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `middlename` varchar(50) NOT NULL,
  `street` varchar(50) NOT NULL,
  `house_no` varchar(50) NOT NULL,
  `barangay` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `bdate` date NOT NULL,
  `status` varchar(50) DEFAULT NULL,
  `spouse_name` varchar(60) NOT NULL,
  `lenghtOfStay` date DEFAULT NULL,
  `is_actived` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL,
  `deleted_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `encode_by` tinyint NOT NULL,
  `image` text,
  `living_status` varchar(50) NOT NULL,
  `civil_status` int NOT NULL,
  `contact_no` varchar(30) NOT NULL,
  `profession` varchar(99) NOT NULL,
  `nationality` varchar(100) NOT NULL,
  `suffix_name` varchar(30) NOT NULL,
  `resident_code` varchar(20) NOT NULL,
  PRIMARY KEY (`resident_info_id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resident_info`
--

LOCK TABLES `resident_info` WRITE;
/*!40000 ALTER TABLE `resident_info` DISABLE KEYS */;
INSERT INTO `resident_info` VALUES (1,'JOHN DENVER','DIAZ','SNOWIE','Binay','125 l4','PIO DEL PILAR','MAKATI CITY','Male','1994-03-10',NULL,'BEA','2023-05-01',1,'2023-05-16 09:08:32','0000-00-00 00:00:00','2023-05-16 09:08:32',0,NULL,'RENTEE',2,'09123456789','DESIGNER','Filipino','','BrgyR20230516-00001'),(2,'Odette','Rodgers','Gary Boyd','Calle Estacion','231','PIO DEL PILAR','MAKATI CITY','Female','2003-08-06','OTHERS','','2016-05-18',1,'2023-05-16 11:11:21','0000-00-00 00:00:00','2023-05-16 11:11:21',0,NULL,'RENTEE',6,'09123456789','DESIGNER','Filipino','','BrgyR20230516-00002'),(3,'Odette','Rodgers','Gary Boyd','Calle Estacion','231','PIO DEL PILAR','MAKATI CITY','Female','2003-08-06','OTHERS','','2016-05-18',1,'2023-05-16 11:11:22','0000-00-00 00:00:00','2023-05-16 11:11:22',0,NULL,'RENTEE',6,'09123456789','DESIGNER','Filipino','','BrgyR20230516-00003'),(4,'Magee','Fuller','Daniel Cochran','Wilson','519','PIO DEL PILAR','MAKATI CITY','Female','1973-03-19','Persons with Disabilities','','1992-05-10',1,'2023-05-16 12:30:07','0000-00-00 00:00:00','2023-05-16 12:30:07',0,NULL,'OWNER',6,'09123456790','FIREFIGHTER','Filipino','','BrgyR20230516-00004'),(5,'Elmo','Barber','Kieran Hall','Jerry','213','PIO DEL PILAR','MAKATI CITY','Male','1985-03-15','OTHERS','','1996-04-26',1,'2023-05-16 12:30:51','0000-00-00 00:00:00','2023-05-16 12:30:51',0,NULL,'RENTEE',3,'09123456791','SCIENTIST','Filipino','','BrgyR20230516-00005'),(6,'Theodore','Frazier','Tara Davidson','Citiland 8 Road','678','PIO DEL PILAR','MAKATI CITY','Female','1991-05-10','Single Parent','','1973-02-02',1,'2023-05-16 12:31:15','0000-00-00 00:00:00','2023-05-16 12:31:15',0,NULL,'OWNER',3,'09123456792','CONSULTANT','Filipino','','BrgyR20230516-00006'),(7,'Michelle','Mendez','Branden Tyson','Calle Estacion','897','PIO DEL PILAR','MAKATI CITY','Female','1978-03-27','OTHERS','','1981-12-06',1,'2023-05-16 12:32:00','0000-00-00 00:00:00','2023-05-16 12:32:00',0,NULL,'OWNER',1,'09123456793','POLICEMAN','Filipino','','BrgyR20230516-00007'),(8,'Xanthus','Dickerson','Caesar Buck','M. Santillan','214','PIO DEL PILAR','MAKATI CITY','Male','1978-05-05','Single Parent','','2001-11-22',1,'2023-05-16 12:32:22','0000-00-00 00:00:00','2023-05-16 12:32:22',0,NULL,'RENTEE',6,'09123456793','DIETITIAN','Filipino','','BrgyR20230516-00008'),(9,'Nigel','Gardner','Serina Baker','McKinley','567','PIO DEL PILAR','MAKATI CITY','Male','1992-06-28','Single Parent','','2008-03-16',1,'2023-05-16 12:32:51','0000-00-00 00:00:00','2023-05-16 12:32:51',0,NULL,'RENTEE',1,'09123456795','ELECTRICIAN','Filipino','','BrgyR20230516-00009'),(10,'Urielle','Knapp','Tasha Cain','Reynaldo','333','PIO DEL PILAR','MAKATI CITY','Female','1994-01-10','OTHERS','','2014-01-23',1,'2023-05-16 12:33:12','0000-00-00 00:00:00','2023-05-16 12:33:12',0,NULL,'RENTEE',4,'09123456796','','Filipino','','BrgyR20230516-00010'),(11,'Len','Jordan','Martin Savage','Antonio S. Arnaiz Avenue','555','PIO DEL PILAR','MAKATI CITY','Female','1975-03-15','Single Parent','','1980-08-19',1,'2023-05-16 12:33:50','0000-00-00 00:00:00','2023-05-16 12:33:50',0,NULL,'OWNER',3,'09123456796','BUSINESSPERSON','Filipino','','BrgyR20230516-00011'),(12,'Hedwig','Stout','Kiayada Estes','Capt. M. Reyes','2677','PIO DEL PILAR','MAKATI CITY','Female','1979-09-21','Senior Citizen','','1979-03-14',1,'2023-05-16 12:34:11','0000-00-00 00:00:00','2023-05-16 12:34:11',0,NULL,'OWNER',3,'09123456798','BUSINESSPERSON','Filipino','','BrgyR20230516-00012'),(13,'Quamar','Austin','Quentin Tyson','Ben Harrison','589','PIO DEL PILAR','MAKATI CITY','Male','1977-06-04','Persons with Disabilities','','1979-11-10',1,'2023-05-16 12:34:36','0000-00-00 00:00:00','2023-05-16 12:34:36',0,NULL,'RENTEE',6,'09123456790','BRICKLAYER','Filipino','','BrgyR20230516-00013'),(14,'MacKensie','Monroe','Demetrius Henry','Hayes','213','PIO DEL PILAR','MAKATI CITY','Male','1972-05-22','Persons with Disabilities','','1973-08-17',1,'2023-05-16 12:35:01','0000-00-00 00:00:00','2023-05-16 12:35:01',0,NULL,'OWNER',5,'09123456789','FIREFIGHTER','Filipino','','BrgyR20230516-00014'),(15,'Kyra','Martinez','Anika Walls','Facundo','546','PIO DEL PILAR','MAKATI CITY','Female','1986-10-28','OTHERS','','2020-10-08',1,'2023-05-16 12:35:25','0000-00-00 00:00:00','2023-05-16 12:35:25',0,NULL,'OWNER',4,'Voluptates facere pr','CHEF','Filipino','','BrgyR20230516-00015'),(16,'Melissa','Chang','Gary Arnold','Taylor','456','PIO DEL PILAR','MAKATI CITY','Female','1986-01-15','Persons with Disabilities','','1987-07-04',1,'2023-05-16 12:35:57','0000-00-00 00:00:00','2023-05-16 12:35:57',0,NULL,'RENTEE',4,'09123456123','PHYSICIAN','Filipino','','BrgyR20230516-00016'),(17,'Meghan','Day','Belle Finch','Citiland 8 Road','333','PIO DEL PILAR','MAKATI CITY','Male','1970-06-07','OTHERS','','1973-10-28',1,'2023-05-16 12:36:29','0000-00-00 00:00:00','2023-05-16 12:36:29',0,NULL,'OWNER',3,'09123456124','ACCOUNTANT','Filipino','','BrgyR20230516-00017'),(18,'Amethyst','Nguyen','Alice Monroe','Pierce','367','PIO DEL PILAR','MAKATI CITY','Male','1972-02-13','Persons with Disabilities','','2020-07-08',1,'2023-05-16 12:36:47','0000-00-00 00:00:00','2023-05-16 12:36:47',0,NULL,'OWNER',3,'09123456125','JUDGE','Filipino','','BrgyR20230516-00018'),(19,'Stacey','Haney','Nadine Spears','Santuico','Quod id itaque blan','PIO DEL PILAR','MAKATI CITY','Female','1970-10-01','Persons with Disabilities','','1971-11-19',1,'2023-05-16 12:37:15','0000-00-00 00:00:00','2023-05-16 12:37:15',0,NULL,'OWNER',4,'09123456126','ARCHITECT','Filipino','','BrgyR20230516-00019'),(20,'Byron','Hamilton','Quintessa Hines','M. Antonio','567','PIO DEL PILAR','MAKATI CITY','Female','2017-12-23','OTHERS','','2020-10-26',1,'2023-05-16 12:37:47','0000-00-00 00:00:00','2023-05-16 12:37:47',0,NULL,'OWNER',1,'09123456129','AUTHOR','Filipino','','BrgyR20230516-00020'),(21,'Colton','Gentry','Tamara Dillard','Hoover','7767','PIO DEL PILAR','MAKATI CITY','Male','1970-08-22','Single Parent','','1988-11-14',1,'2023-05-16 12:41:21','0000-00-00 00:00:00','2023-05-16 12:41:21',0,NULL,'RENTEE',1,'09123456120','GARDENER','Filipino','','BrgyR20230516-00021'),(22,'Larissa','Carlson','Emerald Landry','J. Victor','33','PIO DEL PILAR','MAKATI CITY','Female','2013-06-03','Senior Citizen','','2015-05-17',1,'2023-05-16 12:41:44','0000-00-00 00:00:00','2023-05-16 12:41:44',0,NULL,'OWNER',5,'09123456123','ELECTRICIAN','Filipino','','BrgyR20230516-00022'),(23,'Dora','Sherman','Imogene Valencia','Hoover','356','PIO DEL PILAR','MAKATI CITY','Male','1982-07-29','OTHERS','','1987-08-14',1,'2023-05-16 12:46:45','0000-00-00 00:00:00','2023-05-16 12:46:45',0,NULL,'OWNER',5,'09123456128','TEACHER','Filipino','','BrgyR20230516-00023'),(24,'Idona','Avila','Selma Wade','Facundo','358','PIO DEL PILAR','MAKATI CITY','Female','1992-09-22','Single Parent','','1993-11-24',1,'2023-05-16 12:47:19','0000-00-00 00:00:00','2023-05-16 12:47:19',0,NULL,'RENTEE',3,'09123456129','JUDGE','Filipino','','BrgyR20230516-00024'),(25,'Tatyana','Brennan','Sasha Dyer','Mayor','33','PIO DEL PILAR','MAKATI CITY','Male','1989-05-18','Persons with Disabilities','','2001-11-17',1,'2023-05-16 12:47:51','0000-00-00 00:00:00','2023-05-16 12:47:51',0,NULL,'OWNER',1,'09123456122','ELECTRICIAN','Filipino','','BrgyR20230516-00025');
/*!40000 ALTER TABLE `resident_info` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-31 18:06:24
