CREATE DATABASE  IF NOT EXISTS `u895244394_bams` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `u895244394_bams`;
-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: u895244394_bams
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `certificates`
--

DROP TABLE IF EXISTS `certificates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `certificates` (
  `certificates_id` int NOT NULL AUTO_INCREMENT,
  `certificates_desc` varchar(100) NOT NULL,
  `certificates_body` varchar(30) NOT NULL,
  `certificates_type` varchar(50) NOT NULL,
  `certificates_created_by` varchar(50) NOT NULL,
  `certificates_deleted_by` varchar(50) NOT NULL,
  `certificates_updated_by` varchar(50) NOT NULL,
  `certificates_created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `certificates_updated_at` datetime NOT NULL,
  `certificates_deleted_at` datetime NOT NULL,
  PRIMARY KEY (`certificates_id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `certificates`
--

LOCK TABLES `certificates` WRITE;
/*!40000 ALTER TABLE `certificates` DISABLE KEYS */;
INSERT INTO `certificates` VALUES (1,'AERIAL INSTALLATION','aerial_installation','BUSINESS','','','','2023-01-25 23:16:40','0000-00-00 00:00:00','0000-00-00 00:00:00'),(2,'BUILDING CLEARANCE','building_clearance','BUSINESS','','','','2023-01-25 23:16:40','0000-00-00 00:00:00','0000-00-00 00:00:00'),(3,'BUSINESS CLEARANCE-(WITH PENALTIES)','business_clearance_penalties','BUSINESS','','','','2023-01-25 23:16:40','0000-00-00 00:00:00','0000-00-00 00:00:00'),(4,'BUSINESS CLEARANCE','business_clearance','BUSINESS','','','','2023-01-25 23:16:40','0000-00-00 00:00:00','0000-00-00 00:00:00'),(5,'CABLE INSTALLATION','cable_installation','BUSINESS','','','','2023-01-25 23:16:40','0000-00-00 00:00:00','0000-00-00 00:00:00'),(6,'4P\'S','fourps','CERTIFICATION','','','','2023-01-25 23:16:40','0000-00-00 00:00:00','0000-00-00 00:00:00'),(7,'ANNULMENT PURPOSES','annulment_purposes','CERTIFICATION','','','','2023-01-25 23:16:40','0000-00-00 00:00:00','0000-00-00 00:00:00'),(8,'AVON MEMBERSHIP','avon_membership','CERTIFICATION','','','','2023-01-25 23:16:40','0000-00-00 00:00:00','0000-00-00 00:00:00'),(9,'BAIL BOND PURPOSES','bail_bond_purposes','CERTIFICATION','','','','2023-01-25 23:16:40','0000-00-00 00:00:00','0000-00-00 00:00:00'),(10,'BURIAL ASSISTANCE CLEARANCE','burial_assistance_clearance','CERTIFICATION','','','','2023-01-25 23:16:40','0000-00-00 00:00:00','0000-00-00 00:00:00'),(11,'FINANCIAL ASSISTANCE CLEARANCE','financial_assistance_clearance','CERTIFICATION','','','','2023-01-25 23:16:40','0000-00-00 00:00:00','0000-00-00 00:00:00'),(12,'FOREGNER-VISA PURPOSES','foregner_visa_purposes','CERTIFICATION','','','','2023-01-25 23:16:40','0000-00-00 00:00:00','0000-00-00 00:00:00'),(13,'LOAN PURPOSES','loan_purposes','CERTIFICATION','','','','2023-01-25 23:16:40','0000-00-00 00:00:00','0000-00-00 00:00:00'),(14,'MAKATIZEN\'S CARD','makatizen_card','CERTIFICATION','','','','2023-01-25 23:16:40','0000-00-00 00:00:00','0000-00-00 00:00:00'),(15,'MARRIAGE PURPOSES','marriage_purposes','CERTIFICATION','','','','2023-01-25 23:16:40','0000-00-00 00:00:00','0000-00-00 00:00:00'),(16,'MEDICAL ASSISTANCE CLEARANCE','medical_assistance_clearance','CERTIFICATION','','','','2023-01-25 23:16:40','0000-00-00 00:00:00','0000-00-00 00:00:00'),(17,'METRO STORE PURPOSES','metro_store_purposes','CERTIFICATION','','','','2023-01-25 23:16:40','0000-00-00 00:00:00','0000-00-00 00:00:00'),(18,'MHP PURPOSES','mhp_purposes','CERTIFICATION','','','','2023-01-25 23:16:40','0000-00-00 00:00:00','0000-00-00 00:00:00'),(19,'NBI CLEARANCE','nbi_clearance','CERTIFICATION','','','','2023-01-25 23:16:40','0000-00-00 00:00:00','0000-00-00 00:00:00'),(20,'PAG-IBIG E.S.A.V. (Employee\'s Sttement of Accumulated Value) PURPOSES','pag_ibig_esav','CERTIFICATION','','','','2023-01-25 23:16:40','0000-00-00 00:00:00','0000-00-00 00:00:00'),(21,'PASSPORT ID','passport_id','CERTIFICATION','','','','2023-01-25 23:16:40','0000-00-00 00:00:00','0000-00-00 00:00:00'),(22,'PHILHEALTH CARD','philhealth_card','CERTIFICATION','','','','2023-01-25 23:16:40','0000-00-00 00:00:00','0000-00-00 00:00:00'),(23,'SOLO PARENT ID','solo_parent_id','CERTIFICATION','','','','2023-01-25 23:16:40','0000-00-00 00:00:00','2023-03-19 13:08:13'),(24,'TRANSPORTING PURPOSES','transporting_purposes','CERTIFICATION','','','','2023-01-25 23:16:40','0000-00-00 00:00:00','0000-00-00 00:00:00'),(25,'DEMOLITION CLEARANCE','demolition_clearance','CERTIFICATION','','','','2023-01-25 23:16:40','0000-00-00 00:00:00','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `certificates` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-31 18:06:26
