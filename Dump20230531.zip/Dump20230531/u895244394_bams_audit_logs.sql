CREATE DATABASE  IF NOT EXISTS `u895244394_bams` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `u895244394_bams`;
-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: u895244394_bams
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_logs` (
  `audit_log_id` int NOT NULL AUTO_INCREMENT,
  `audit_log_action` varchar(45) DEFAULT NULL,
  `audit_log_from` varchar(99) DEFAULT NULL,
  `audit_log_to` varchar(99) DEFAULT NULL,
  `audit_log_field_name` varchar(99) DEFAULT NULL,
  `audit_log_pk_id` int DEFAULT NULL,
  `audit_log_created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `audit_log_updated_at` datetime DEFAULT NULL,
  `audit_log_deleted_at` datetime DEFAULT NULL,
  `audit_log_created_by` varchar(99) DEFAULT NULL,
  `audit_log_table` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`audit_log_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES (1,'EDIT','Male','Male1','gender_desc',NULL,'2022-09-23 16:38:50','2022-09-23 16:38:50',NULL,NULL,'gender'),(2,'EDIT','Male1','Male','gender_desc',NULL,'2022-09-23 16:39:03','2022-09-23 16:39:03',NULL,NULL,'gender'),(3,'EDIT','Male','Male1','gender_desc',NULL,'2022-09-23 16:39:10','2022-09-23 16:39:10',NULL,NULL,'gender'),(4,'EDIT','sample','sample001','id_type_desc',NULL,'2022-09-23 16:39:44','2022-09-23 16:39:44',NULL,NULL,'id_type'),(5,'EDIT','Male1','Male','gender_desc',NULL,'2022-09-23 16:41:56','2022-09-23 16:41:56',NULL,NULL,'gender'),(6,'EDIT','','1','position_level',NULL,'2022-09-23 16:43:22','2022-09-23 16:43:22',NULL,NULL,'position'),(7,'EDIT','','1','position_level',NULL,'2022-09-23 16:43:54','2022-09-23 16:43:54',NULL,NULL,'position'),(8,'EDIT','Captain','Captain1','position_desc',NULL,'2022-09-23 16:50:46','2022-09-23 16:50:46',NULL,NULL,'position'),(9,'EDIT','1','12','position_level',NULL,'2022-09-23 16:50:46','2022-09-23 16:50:46',NULL,NULL,'position'),(10,'EDIT','12','1','position_level',NULL,'2022-09-27 10:04:48','2022-09-27 10:04:48',NULL,NULL,'position'),(11,'EDIT','1','','position_level',NULL,'2022-09-27 10:05:18','2022-09-27 10:05:18',NULL,NULL,'position'),(12,'EDIT','','1','position_level',NULL,'2022-09-27 10:05:23','2022-09-27 10:05:23',NULL,NULL,'position');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-31 18:06:25
