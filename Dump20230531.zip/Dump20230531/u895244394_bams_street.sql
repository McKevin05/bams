CREATE DATABASE  IF NOT EXISTS `u895244394_bams` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `u895244394_bams`;
-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: u895244394_bams
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `street`
--

DROP TABLE IF EXISTS `street`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `street` (
  `street_id` int NOT NULL AUTO_INCREMENT,
  `street_desc` varchar(50) NOT NULL,
  `street_created_by` varchar(50) NOT NULL,
  `street_deleted_by` varchar(50) NOT NULL,
  `street_updated_by` varchar(50) NOT NULL,
  `street_created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `street_updated_at` datetime NOT NULL,
  `street_deleted_at` datetime NOT NULL,
  PRIMARY KEY (`street_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `street`
--

LOCK TABLES `street` WRITE;
/*!40000 ALTER TABLE `street` DISABLE KEYS */;
INSERT INTO `street` VALUES (1,'Antonio S. Arnaiz Avenue','','','','2023-05-15 23:49:49','0000-00-00 00:00:00','0000-00-00 00:00:00'),(2,'Arguelles','','','','2023-05-15 23:49:49','0000-00-00 00:00:00','0000-00-00 00:00:00'),(3,'Balderama','','','','2023-05-15 23:49:49','0000-00-00 00:00:00','0000-00-00 00:00:00'),(4,'Ben Harrison','','','','2023-05-15 23:49:49','0000-00-00 00:00:00','0000-00-00 00:00:00'),(5,'Binay','','','','2023-05-15 23:49:49','0000-00-00 00:00:00','0000-00-00 00:00:00'),(6,'Calhoun','','','','2023-05-15 23:49:49','0000-00-00 00:00:00','0000-00-00 00:00:00'),(7,'Calle Estacion','','','','2023-05-15 23:49:49','0000-00-00 00:00:00','0000-00-00 00:00:00'),(8,'Capt. M. Reyes','','','','2023-05-15 23:49:49','0000-00-00 00:00:00','0000-00-00 00:00:00'),(9,'Citiland 8 Road','','','','2023-05-15 23:49:49','0000-00-00 00:00:00','0000-00-00 00:00:00'),(10,'Cuangco','','','','2023-05-15 23:49:49','0000-00-00 00:00:00','0000-00-00 00:00:00'),(11,'E. Jacinto','','','','2023-05-15 23:49:49','0000-00-00 00:00:00','0000-00-00 00:00:00'),(12,'E. Ramos','','','','2023-05-15 23:49:49','0000-00-00 00:00:00','0000-00-00 00:00:00'),(13,'Facundo','','','','2023-05-15 23:49:49','0000-00-00 00:00:00','0000-00-00 00:00:00'),(14,'Fernando','','','','2023-05-15 23:49:49','0000-00-00 00:00:00','0000-00-00 00:00:00'),(15,'Hayes','','','','2023-05-15 23:49:49','0000-00-00 00:00:00','0000-00-00 00:00:00'),(16,'Hoover','','','','2023-05-15 23:49:49','0000-00-00 00:00:00','0000-00-00 00:00:00'),(17,'J. Victor','','','','2023-05-15 23:49:49','0000-00-00 00:00:00','0000-00-00 00:00:00'),(18,'Jerry','','','','2023-05-15 23:49:49','0000-00-00 00:00:00','0000-00-00 00:00:00'),(19,'M. Antonio','','','','2023-05-15 23:49:49','0000-00-00 00:00:00','0000-00-00 00:00:00'),(20,'M. Ocampo','','','','2023-05-15 23:49:49','0000-00-00 00:00:00','0000-00-00 00:00:00'),(21,'M. Santillan','','','','2023-05-15 23:49:49','0000-00-00 00:00:00','0000-00-00 00:00:00'),(22,'Mayor','','','','2023-05-15 23:49:49','0000-00-00 00:00:00','0000-00-00 00:00:00'),(23,'McKinley','','','','2023-05-15 23:49:49','0000-00-00 00:00:00','0000-00-00 00:00:00'),(24,'Pierce','','','','2023-05-15 23:49:49','0000-00-00 00:00:00','0000-00-00 00:00:00'),(25,'Reynaldo','','','','2023-05-15 23:49:49','0000-00-00 00:00:00','0000-00-00 00:00:00'),(26,'Roosevelt','','','','2023-05-15 23:49:49','0000-00-00 00:00:00','0000-00-00 00:00:00'),(27,'S. Javier','','','','2023-05-15 23:49:49','0000-00-00 00:00:00','0000-00-00 00:00:00'),(28,'Santuico','','','','2023-05-15 23:49:49','0000-00-00 00:00:00','0000-00-00 00:00:00'),(29,'Taylor','','','','2023-05-15 23:49:49','0000-00-00 00:00:00','0000-00-00 00:00:00'),(30,'Van Buren','','','','2023-05-15 23:49:49','0000-00-00 00:00:00','0000-00-00 00:00:00'),(31,'Washington','','','','2023-05-15 23:49:49','0000-00-00 00:00:00','0000-00-00 00:00:00'),(32,'Wilson','','','','2023-05-15 23:49:49','0000-00-00 00:00:00','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `street` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-31 18:06:24
